#pragma once
extern void impiegato_controller(void);