#pragma once
extern void manager_controller(void);