#pragma once

extern void administrator_controller(void);
