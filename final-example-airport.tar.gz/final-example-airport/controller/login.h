#pragma once
#include <stdbool.h>

extern bool login(void);
